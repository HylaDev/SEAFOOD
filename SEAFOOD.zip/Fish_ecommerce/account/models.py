from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class MyUserManager(BaseUserManager):
    def create_user(self, email, password=None):
        if not email:
            raise ValueError("Email est obligatoire")
      
        client=self.model(
            email=self.normalize_email(email),
        )

        client.set_password(password)
        client.save(using=self._db)
        return client
    
    def create_superuser(self,email,password=None):
        admin=self.create_user(
            email=self.normalize_email(email),
            password = password
        )
        
        admin.is_admin=True
        admin.is_staff=True
        admin.is_superuser=True
        admin.save(using=self._db)
        return admin



class MyUser(AbstractBaseUser):
    email = models.EmailField(verbose_name="Adresse email", max_length=60, unique=True)
    date_joined = models.DateTimeField(verbose_name="date joined", auto_now_add=True)
    last_login = models.DateTimeField(verbose_name="last login", auto_now=True)
    is_admin = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)

    USERNAME_FIELD="email"
    

    REQUIRED_FIELDS=[]

    objects=MyUserManager()

    def __str__(self):
        return self.email

    def has_perm(self, perm, obj=None):
        return True
    
    def has_module_perms(self, app_label):
        return True
    

class Admin(MyUser):

    admin_id = models.OneToOneField(
        MyUser, on_delete=models.CASCADE,
        parent_link=True,
        primary_key=True,
        )
    nom = models.CharField(verbose_name="Nom", max_length=50)
    prenom =models.CharField(verbose_name="Prenom",max_length=50)
    poste= models.CharField(verbose_name="Poste occupé",max_length=80)
    adresse = models.CharField(verbose_name="Adresse", max_length=100)
    telephone = models.CharField(verbose_name="Telephone", max_length=20)

    REQUIRED_FIELDS=['nom', 'prenom', 'poste', 'adresse', 'telephone']

    def __str__(self):
        return self.email

class TypeClient(models.Model):
    TypeClientId = models.AutoField(primary_key=True)
    designation = models.CharField(max_length=50)

    def __str__(self):
        return self.designation
    

class Client(MyUser):

    client_id = models.OneToOneField(
        MyUser, on_delete=models.CASCADE,
        parent_link=True,
        primary_key=True,
        )
    nom = models.CharField(verbose_name="Nom", max_length=50)
    prenom =models.CharField(verbose_name="Prenom",max_length=50)
    entreprise= models.CharField(verbose_name="Nom de la société", max_length=80)
    adresse = models.CharField(verbose_name="Adresse", max_length=100)
    telephone = models.CharField(verbose_name="Telephone", max_length=20)
    TypeClientId = models.ForeignKey(TypeClient, on_delete=models.CASCADE,default=1)

    REQUIRED_FIELDS=['nom', 'prenom', 'adresse', 'telephone']

    def __str__(self):
        return self.email
    

class CategoriesProduits(models.Model):
    CategorieId = models.AutoField(primary_key=True, auto_created=True)
    designation = models.CharField(max_length=50)

    def __str__(self):
        return self.designation


class Produit(models.Model):
    ProduitId = models.AutoField(primary_key=True, auto_created=True)
    refProduit = models.CharField(max_length=100, unique=True)
    image = models.ImageField(upload_to="products/%Y/%m/%d",null=True, blank=True)
    designation = models.CharField(max_length=50)
    description = models.TextField()
    CategorieId = models.ForeignKey(CategoriesProduits, on_delete=models.CASCADE)
    prixVente = models.FloatField()
    def __str__(self):
        return self.refProduit
        

class Commande(models.Model):
    CommandeId =models.AutoField(primary_key=True)
    ClientId = models.ForeignKey(Client, on_delete=models.CASCADE)
    dateCommande  = models.DateTimeField()


class DetailCommande(models.Model):
    DetailId = models.AutoField(primary_key=True)
    CommandeId = models.ForeignKey(Commande, on_delete=models.CASCADE)
    ProduitId = models.ForeignKey(Produit, on_delete=models.CASCADE)
    quantiteProduit = models.IntegerField()
    Montant = models.FloatField()


class Facture(models.Model):
    FactureId = models.AutoField(primary_key=True)
    numFacture = models.IntegerField()
    date = models.DateTimeField()
    prixHT = models.FloatField()
    TVA = models.FloatField()
    montantTotal = models.FloatField()
    DetailId = models.ForeignKey(DetailCommande, on_delete=models.CASCADE )


class Commentaire(models.Model):
    CommentaireId  = models.AutoField(primary_key=True)
    ClientId = models.ForeignKey(Client, on_delete=models.CASCADE)
    commentaire = models.TextField()
    date = models.DateTimeField()


class Fournisseur(models.Model):
    FournisseurId = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=50)
    prenom =models.CharField(max_length=50)
    nom_societe= models.CharField(max_length=80)
    adresse = models.CharField(max_length=100)
    email = models.EmailField(max_length=254)
    telephone = models.CharField(max_length=20)

class Approvisionnement(models.Model):
    ApprovisionnementId = models.AutoField(primary_key=True)
    FournisseurId = models.ForeignKey(Fournisseur, on_delete=models.CASCADE)
    idProduit = models.ForeignKey(Produit, on_delete=models.CASCADE)
    quantiteProduit = models.IntegerField()
    dateApprovisionnement = models.DateTimeField()
    prixApprovisionnement = models.FloatField()    

   
class Balance(models.Model):
    BalanceId = models.AutoField(primary_key=True)
    ClientId = models.ForeignKey(Client, on_delete=models.CASCADE)
    solde = models.FloatField()

class Parametre(models.Model):
    ParametreId = models.AutoField(primary_key=True)
    ClientId = models.ForeignKey(Client, on_delete=models.CASCADE)
    reduction = models.FloatField() 
    
class Stock(models.Model):
    StockId = models.AutoField(primary_key=True)
    ProduidId = models.ForeignKey(Produit, on_delete=models.CASCADE)
    QuantiteActuelle = models.IntegerField()
    
