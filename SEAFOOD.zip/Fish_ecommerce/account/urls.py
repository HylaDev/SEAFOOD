from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.home, name="dashboard"),
    path('register/', views.register, name="register"),
    path('login/', views.login_view, name="login"),
    path('logout/', views.logout_view, name="logout"),
    path('', views.index, name="index"),
    path('boutique/', views.boutique, name="boutique"),
    path('propos/', views.propos, name="propos"),
    path('contact/', views.contact, name="contact"),
    path('panier/', views.panier, name="panier"),
    path('detail/',views.detail, name="detail"),
    path('finalisation/',views.finalisation, name="finalisation"),

]
