from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from account.models import *
# Register your models here.

class ClientAdmin(BaseUserAdmin):
    list_display=('email', 'prenom', 'nom', 'entreprise','telephone', 'adresse')
    search_fields=('email','prenom','nom', 'entreprise')
    readonly_fields=('date_joined', 'last_login',)
    filter_horizontal=()
    list_filter=('last_login',)
    fieldsets=()

    add_fieldsets=(
        (None, {
            'classes':('wide'),
            'fields':('email','prenom', 'nom', 'entreprise','telephone', 'adresse'),
        }),
    )

    ordering=('email',)

class MyUserAdmin(BaseUserAdmin):
    list_display=('email', 'date_joined', 'last_login', 'is_admin', 'is_active')
    readonly_fields=('date_joined', 'last_login',)
    filter_horizontal=()
    list_filter=('last_login',)
    fieldsets=()

    add_fieldsets=(
        (None, {
            'classes':('wide'),
            'fields':('email', 'password1', 'password2'),
        }),
    )

    ordering=('email',)
admin.site.register(MyUser, MyUserAdmin)
admin.site.register(Produit)
admin.site.register(CategoriesProduits)
admin.site.register(TypeClient)
admin.site.register(Client, ClientAdmin)

