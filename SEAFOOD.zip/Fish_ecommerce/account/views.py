from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from account.forms import UserRegistrationForm, UserLoginForm
from .models import Produit
# Create your views here.

def index(request):
    produits=Produit.objects.all()
    context={'produits':produits}
    return render(request, "pages/index_2.html",context)


def boutique(request):
    produits=Produit.objects.all()
    context={'produits':produits}
    return render(request, "pages/shop.html",context)

def propos(request):
    return render(request, "pages/about.html")

def contact(request):
    return render(request, "pages/contact.html")

def panier(request):
    return render(request, "pages/cart.html")

def home(request):
    return render(request, "account/dashboard.html")

def detail(request):
    produits=Produit.objects.all()
    context={'produits':produits}
    return render(request, "pages/single-product.html",context)

def finalisation(request):
    return render(request, "pages/checkout.html")


def register(request):
    context={}
    if request.POST:
        form=UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
        context['register_form']=form
    
    else:
        form=UserRegistrationForm()
        context['register_form']=form
    return render(request, "account/register.html", context)



def login_view(request):
    context={}
    if request.POST:
        form=UserLoginForm(request.POST)
        if form.is_valid():
            email=request.POST['email']
            password=request.POST['password']
            user=authenticate(request, email=email, password=password)
        
            if user is not None:
                login(request, user)
                return redirect("index")
        else:
            context['login_form']=form


    else:
        form=UserLoginForm()
        context['login_form']=form

    return render(request, "account/login.html", context)

def logout_view(request):
    logout(request)
    return redirect('login')